import { join } from 'path'
import {messageContinue, messageEmptyArray, messageInfo, messageOptions, messageWelcome} from "./messages";
import {existUser, fetchData, getCampaniasChange, getRequisicionesChange} from "./changeData";
import {getCampanias, getGlobalData, getRequisiciones, getuser} from "./setData";
import capitalizeFirstWord from "./leetersUpper";
import returnToInitFlow from "./returnToInit.Flow";
import {gestionaRespuestas} from "./returnToAnwers.Flow";
import { addKeyword, EVENTS } from "@builderbot/bot";

export default addKeyword(EVENTS.WELCOME)
    .addAnswer('Hola',{capture:false}, async (ctx,{flowDynamic,state,fallBack,gotoFlow}) =>{
        await flowDynamic(ctx.pushName)
        //fetchData(ctx.body);
    })
    .addAnswer(`Te envio esta imagen`,{ media: join(process.cwd(), 'assets', 'sample.png') })
    /*.addAnswer('🌟 ¡Hola ', { capture: false }, async (ctx, { flowDynamic, state, fallBack ,gotoFlow}) => {
        try {
            await existUser(ctx.from);
            await state.update({ user: ctx.pushName });
            if (getuser()[0][0] === 'null') {
                await flowDynamic(messageWelcome(ctx.pushName));
            }
            await getCampaniasChange(ctx.body.slice(1));
                const globalData = await getCampanias();
                if (globalData) {
                    await flowDynamic(globalData.MESSAGE);
                    if (globalData.Campanias) {
                        const campanias = await Promise.all(globalData.Campanias.map(async (x, index) => {
                            return `${index + 1}. ${await capitalizeFirstWord(x.Campania)}`;
                        }));
                        await state.update({exit: campanias.length + 1});
                        await state.update({type: 'number'});
                        await state.update({current: null});
                        campanias.push((campanias.length + 1) + '. Salir');
                        await state.update({currentmessage: campanias.join('\n')});
                        await flowDynamic(messageOptions() + '\n' + campanias.join('\n'));
                    } else {
                        return fallBack(messageInfo());
                        return gotoFlow(returnToInitFlow);
                    }
                } else {
                    await flowDynamic('❌ **Error:** No se pudo obtener la información global.');
                }
        } catch (error) {
            console.error('Error en el flujo de bienvenida:', error);
            await flowDynamic('⚠️ **Error:** Ocurrió un problema al procesar tu solicitud. Por favor, inténtalo de nuevo más tarde.');
        }
    })
    .addAnswer(messageContinue(), { delay: 100, capture: true }, async (ctx, { flowDynamic, state, fallBack, gotoFlow }) => {
        try {
            const globalData = await getCampanias();
            const selectedOption = parseInt(ctx.body);
            let dataCampain = globalData.Campanias[selectedOption-1];
            await state.update({IDOrg: dataCampain['IDOrg']});
            if (state.get('type') === 'number') {
                if (isNaN(selectedOption) || selectedOption < 1 || selectedOption > state.get('exit')) {
                    return fallBack('⚠️ **Error:** Por favor, ingresa una opción válida dentro del rango.');
                } else {
                    await state.update({ Campania: dataCampain['ID'] });
                    await flowDynamic('👍 *Opción seleccionada:* ' + selectedOption + '. Procedamos...');
                    // @ts-ignore
                    const Data = globalData.Campanias;
                    let arreglo =  Data[selectedOption-1]['ID'];
                    await getRequisicionesChange(state.get('IDOrg'),arreglo);
                    const requisicion = await getRequisiciones();
                    if (requisicion){
                        let x :any;
                        x = await Promise.all(requisicion['Requisiciones'].map(async (x, index) => {
                            if (x.NOMBRE_REQUISICION != '')
                                return `${index + 1}. `+ await capitalizeFirstWord(`${x.NOMBRE_REQUISICION}`);
                            else
                                return '';
                        }));
                        if (x[0] !=''){
                            await state.update({exit: x.length+1});
                            x.push( (x.length+1)+'. Salir');
                            x = x.join('\n');
                            await flowDynamic(x);
                        }
                        else{
                            await state.update({error: 1});
                            await flowDynamic (messageEmptyArray());
                            return gotoFlow(returnToInitFlow);
                        }
                    }else {
                        await flowDynamic('❌ **Error:** No se pudo obtener las requisiciones.');
                    }
                }
            } else {
                return fallBack('⚠️ **Error:** Se solicita una opción de tipo numérico. Por favor, elige una opción válida.');
            }
        } catch (error) {
            console.error('Error en la selección de opciones:', error);
            await flowDynamic('⚠️ **Error:** Ocurrió un problema al procesar tu selección. Por favor, inténtalo de nuevo.');
            return gotoFlow(returnToInitFlow);
        }
    })
.addAnswer(messageContinue(),{capture:true}, async (ctx, { flowDynamic, state, fallBack, gotoFlow }) => {
    try {
        if (state.get('exit') == ctx.body) {
            return gotoFlow(returnToInitFlow);
        }else{
            await state.update({total:0});
            const selectedOption = parseInt(ctx.body);
            if (state.get('type') === 'number') {
                if (isNaN(selectedOption) || selectedOption < 1 || selectedOption > state.get('exit')) {
                    return fallBack('⚠️ **Error:** Por favor, ingresa una opción válida dentro del rango.');
                } else {
                    let ans = state.get('answers') != undefined ? state.get('answers'):[];
                    const requisicion = await getRequisiciones();
                    await state.update({ Requisicion: requisicion['Requisiciones'][selectedOption-1]['ID_REQUISICION']});
                    await flowDynamic('👍 *Opción seleccionada:* ' + selectedOption + '. Procedamos...');
                    let cunter = isNaN(parseInt(state.get('current')))?null:parseInt(state.get('current'));
                    let x:any = await gestionaRespuestas(parseInt(state.get('Requisicion')),ctx.from,ctx.pushName,cunter,parseInt(state.get('Campania')),parseInt(state.get('Requisicion')),state.get('type'),ans);
                    if (typeof x !== "string") {
                        if(x.answers != '')
                            ans.push(x.answers);
                        await state.update({answers:ans});
                        await state.update({total:x.total});
                        await state.update({current:x.current});
                        await state.update({type:x.type});
                        if (parseInt( state.get('current') ) <=  parseInt(state.get('total'))){
                           return  fallBack(x.message);
                        }
                    }

                }
            }
            else if (state.get('type') === 'abierta'){
                let ans = state.get('answers') != undefined ? state.get('answers'):[];
                let cunter = isNaN(parseInt(state.get('current')))?null:parseInt(state.get('current'));
                let x:any = await gestionaRespuestas(ctx.body.toLowerCase(),ctx.from,ctx.pushName,cunter,parseInt(state.get('Campania')),parseInt(state.get('Requisicion')),state.get('type'),ans);
                if (typeof x !== "string") {
                    await state.update({total:x.total});
                    await state.update({current:x.current});
                    await state.update({type:x.type});
                    ans.push(x.answers);
                    await state.update({answers:ans});
                    if (parseInt( state.get('current') ) <=  parseInt(state.get('total'))){
                        return  fallBack(x.message);
                    }else{
                        return gotoFlow(returnToInitFlow);
                    }
                }
            }

        }

    } catch (error) {
        console.error('Error en la selección de opciones:', error);
        await flowDynamic('⚠️ **Error:** Ocurrió un problema al procesar tu selección. Por favor, inténtalo de nuevo.');
    }
    })*/