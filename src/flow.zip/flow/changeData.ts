
import fetch from 'node-fetch';
import {changeCampanias, changeRequisiciones, dateASS, setGlobalData, userexist} from "./setData";

export async function fetchData(params:any) {
    console.log('Apenas entro');
    const url = 'https://hirbo.arvispace.com/services/Back/Rutas.php?Hirbo';
    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({'message': params})
        });

        const data = await response.json();
        console.log(data);
        changeCampanias(data);
    } catch (error) {
        console.error('Error fetching data with params:', error);
        throw error;
    }
}
export async  function changeCandidato(params:any){
    const url = 'https://hirbo.arvispace.com/services/Back/Rutas.php?insertValue';
    try {
        let dta = JSON.stringify({'valores': params,'action':'candidatos'});
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: dta
        });
        console.log(dta);
        console.log(await response.json());
    } catch (error) {
        console.error('Error al asignar candidato:', error);
        throw error;
    }
}
export async  function existUser(number:any){
    const url = 'https://hirbo.arvispace.com/services/Back/Rutas.php?infoCandidato';
    try {
        let dta = JSON.stringify({'numero': number});
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: dta
        });
        userexist( await response.json());
    } catch (error) {
        console.error('Error al asignar candidato:', error);
        throw error;
    }
}
export async  function asignfecha(campania:any,org:any,name:any,requi:any){
    const url = 'https://hirbo.arvispace.com/services/Back/Rutas.php?getFechaInterview';
    try {
        let dta = JSON.stringify({'id_campania': campania,"id_org":org,'name':name,'area':requi});
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: dta
        });
        console.log(dta);
        dateASS( await response.json());
    }catch (error) {
        console.error('Error al asignar candidato:', error);
        throw error;
    }
}
export async  function getCampaniasChange(key:any){
    const url = 'https://hirbo.arvispace.com/services/Back/Rutas.php?getCampanias';
    try {
        let dta = JSON.stringify({"key":key});
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: dta
        });
        changeCampanias( await response.json());
    }catch (error) {
        console.error('Error al obtener  campañas:', error);
        throw error;
    }
}
export async  function getRequisicionesChange(org:any,campain:any){
    const url = 'https://hirbo.arvispace.com/services/Back/Rutas.php?getRequisiciones';
    try {
        let dta = JSON.stringify({"id_org":org,"id_campain":campain});
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: dta
        });
        changeRequisiciones( await response.json());
    }catch (error) {
        console.error('Error al obtener  campañas:', error);
        throw error;
    }
}
export async  function getAnswersChange(org:any,campain:any){
    const url = 'https://hirbo.arvispace.com/services/Back/Rutas.php?getQuestions';
    try {
        let dta = JSON.stringify({"id_org":org,"id_campain":campain});
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: dta
        });
        changeRequisiciones( await response.json());
    }catch (error) {
        console.error('Error al obtener  campañas:', error);
        throw error;
    }
}
