export default function capitalizeFirstWord(sentence: string): string {

    let words = sentence.trim().split(/\s+/);

    if (words.length === 0) {
        return "";
    }

    let firstWord = words[0].charAt(0).toUpperCase() + words[0].slice(1).toLowerCase();

    let restOfWords = words.slice(1).map(word => word.toLowerCase());

    return [firstWord, ...restOfWords].join(' ');
}