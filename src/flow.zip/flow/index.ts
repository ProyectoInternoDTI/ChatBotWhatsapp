import { createFlow } from "@builderbot/bot";
import initFlow from "./initFlow";

export const adapterFlow = createFlow([
        initFlow
    ])