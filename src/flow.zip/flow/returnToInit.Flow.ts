import initFlow from "./initFlow";
import {messageExit} from "./messages";
import { addKeyword, EVENTS } from "@builderbot/bot";

export default addKeyword(EVENTS.ACTION)
    .addAction(async (ctx, { gotoFlow ,flowDynamic}) => {
        await flowDynamic(messageExit(ctx.pushName));
        return gotoFlow(initFlow)
    })