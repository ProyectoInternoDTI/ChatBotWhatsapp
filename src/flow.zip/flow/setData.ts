let globalData: any = null;
let user: any = null;
let dateAsign: any = null;
let messages: any = null;
let Campanias: any = null;
let Requisiciones: any = null;
let userState = new Map();

export function setGlobalData(data: any) {
      globalData = data.response;
}

export function userexist(data: any) {
      user = data.response;
}
export function dateASS(data: any) {
    dateAsign = data.response;
}
export function changeCampanias(data: any) {
    Campanias = data.response;
}
export function changeRequisiciones(data: any) {
    Requisiciones = data.response;
}

export function getGlobalData() {
    return globalData;
}
export function getCampanias() {
    return Campanias;
}
export function getRequisiciones() {
    return Requisiciones;
}
export function getuser() {
    return user;
}
export function getDate() {
    return dateAsign;
}
export function stateUser(number:any,stated: any) {
    userState.set(number, stated);
}
export function setMessage(messa:any) {
    console.log('Ya seteo  los valores');
    console.log(messa);
    messages = messa;
}
export function getstateUser() {
    return userState;
}
export function getmessage() {
    console.log('Esta sacando estos valores');
    console.log(messages);
    return messages;
}
export function clearState(stateglobal){
    stateglobal.step = 'Key';
    stateglobal.strickes = 0;
    stateglobal.campania = null;
    stateglobal.requesicion = null;
    stateglobal.preguntas.current = null;
    stateglobal.preguntas.total = null;
    stateglobal.exit = 0;
    stateglobal.error = 0;
    stateglobal.preguntas.complete = 0;
    stateglobal.preguntas.correctas = 0;
    stateglobal.respuestas.idPregunta = [];
    stateglobal.respuestas.respuestas = [];
    return stateglobal;
}
