import {getDate, getGlobalData} from "./setData";
import {messageConclude, messageEmptyArray, messageExitNull, messageReloadAnswer} from "./messages";
import {asignfecha, changeCandidato} from "./changeData";
import capitalizeFirstWord from "./leetersUpper";

export async function gestionaRespuestas(indice: any, numero: any, nombre: string,current:number,campania:number,Requisicion:number,oldtype:any,ans:any) {
    try {
        let message:any ;
        let exit:any = 0; let type:any = 'number';
        let answers:any = '';
        const Datas = await getGlobalData();
        const Data = Datas['Campanias'];
        let arreglo = Data[campania - 1];
        let totalitems = Data[campania-1]['Preguntas'][Requisicion-1].length;
        if (current == totalitems  && current != null) {
            if (isNaN(parseInt(indice)) && oldtype == 'abierta')
                ans.push(indice);
            else
                ans.push(arreglo['Respuestas'][Requisicion - 1][current][indice-1]);
            await changeCandidato({'FK_ID_ORGANIZACION':Datas['IDOrg'],'NUMERO_CANDIDATO':numero,'FK_ID_REQUISICION':Data[campania-1]['IDS'][Requisicion-1].join(''),'NOMBRE_CANDIDATO':nombre,'RESPUESTAS':ans.join(',')});
            await asignfecha(campania,Datas['IDOrg'],nombre,Data[campania-1]['IDS'][Requisicion-1].join(''));
            exit = 2;
            if(getDate()[0]==  'No hay automatizacion'){
                message = messageConclude(nombre);
            }else {
                message ='¡La entrevista ha concluido satisfactoriamente! Apreciamos mucho tu interés en el puesto. 💼💬 \n'+ getDate()[0]  ;
            }
        }else {
            if (current == null) {
                current = 0;
            }
            if (current>0 && current < totalitems){
                if (isNaN(parseInt(indice)) && oldtype == 'abierta')
                    answers = indice;
                else
                    answers = arreglo['Respuestas'][Requisicion - 1][current][indice-1];
            }
            message = arreglo['Preguntas'][Requisicion - 1][current];
            let ans: any;
            let preguntas = arreglo['Respuestas'][Requisicion - 1][current];


            if (preguntas[0] !=  '') {
                if (current < totalitems)
                    ans = await Promise.all(preguntas.map(async (x, index) => {
                        if (x.toLowerCase() == 'abierta') {
                            exit = 1;
                            type = 'abierta';
                            return '1.Salir';
                        } else
                            return `${index + 1}. ` + await capitalizeFirstWord(`${x}`) + '\n';
                    }));
                if (exit == 0) {
                    exit = preguntas.length + 1;
                    ans += (preguntas.length + 1) + '. Salir';
                }
                message += '\n' + ans;
                if (current < totalitems) {
                    current++;
                }
            } else {
                message =  messageEmptyArray();
            }
        }
                    return {message,exit,total:totalitems,current,type,answers};
    } catch (error) {
        console.log('Error en las pruebas');
        return messageReloadAnswer();
    }
}
